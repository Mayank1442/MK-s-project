<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Children's Walking Shoes</title>

    <!-- Include Bootstrap CSS for basic styling (optional) -->
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="css/product.css">

    <!-- Include jQuery -->
    <script src="jquery.min.js"></script>
 <!-- Include jQuery for puma_shoes page -->
 <script src="jquery/product.js"></script>

</head>

<body>
<nav class="navbar">
        <div class="logo">
            <a><img src="images/logo.PNG" width="40" height="40" alt="logo"></a>
        </div>
        <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
            <li class="dropdown">
                <a href="#">Men</a>
                <ul class="dropdown-menu">
                    <li><a href="men_sneaker.php">Sneaker</a></li>
                    <li><a href="men_walking_shoes.php">Walking Shoes</a></li>
                    <li><a href="men_formal_shoes.php">Formal Shoes</a></li>
                    <li><a href="men_clogs.php">Clogs</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">Women</a>
                <ul class="dropdown-menu">
                    <li><a href="women_clog.php">Clogs</a></li>
                    <li><a href="women_sneaker.php">Sneakers</a></li>
                    <li><a href="women_sandal.php">Sandals</a></li>
                    <li><a href="women_slider.php">Slider</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">Children</a>
                <ul class="dropdown-menu">
                    <li><a href="children_clog.php">Clogs</a></li>
                    <li><a href="children_sandal.php">Sandals</a></li>
                    <li><a href="children_walking_shoes.php">Walking Shoes</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">Sport</a>
                <ul class="dropdown-menu">
                    <li><a href="cricket_shoes.php">Cricket Shoes</a></li>
                    <li><a href="football_shoes.php">FootBall Shoes</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">School</a>
                <ul class="dropdown-menu">
                    <li><a href="Boy_school_shoes.php">Boys School Shoes</a></li>
                    <li><a href="Girl_school_shoes.php">Girls School Shoes</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">Brand</a>
                <ul class="dropdown-menu">
                    <li><a href="puma_shoes.php">puma</a></li>
                    <li><a href="nike.php">nike</a></li>
                </ul>
            </li>
            <li><a href="sale.php">Sale</a></li>

            <li><a href="contact_us.php">Contact</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="sign_in.php"><img src="images/adminprofile.png"alt="" width="30px" height="30px"></a></li>
         
        </ul>
    </nav>

    <br>
    <div>
        <center>
            <h3>Puma Shoes</h3>
        </center>
    </div>

    <div class="container my-5">
        <div class="row">
            <!--product1-->
            <div class="col-md-4 mb-4">
                <div class="product-card">
                    <div class="product-image">
                        <img src="images/puma_shoes/puma1.jpg" class="img-fluid h-100 w-100"
                            alt="The Dependables: Black-Blue">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Brand : puma</h5>
                        <h5 class="product-name">Puma Boy's Shoes</h5>
                        <p class="price"> Rs.4300 </p>
                        <button class="btn btn-dark w-100">ADD TO CART</button>
                    </div>
                </div>
            </div>
            <!--product2 -->
            <div class="col-md-4 mb-4">
                <div class="product-card">
                    <div class="product-image">
                        <img src="images/puma_shoes/puma2.jpg" class="img-fluid h-100 w-100" alt="">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Brand : puma</h5>
                        <h5 class="product-name">Puma Girl's Shoes</h5>
                        <p class="price"> Rs. 2000 </p>
                        <button class="btn btn-dark w-100">ADD TO CART</button>
                    </div>
                </div>
            </div>
            <!--product3-->
            <div class="col-md-4 mb-4">
                <div class="product-card">
                    <div class="product-image">
                        <img src="images/puma_shoes/puma3.jpg" class="img-fluid h-100 w-100" alt="">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Brand : puma</h5>
                        <h5 class="product-name">Puma Boy's Shoes</h5>
                        <p class="price"> Rs.1250 </p>
                        <button class="btn btn-dark w-100">ADD TO CART</button>
                    </div>
                </div>
            </div>

            <!--product4-->
            <div class="col-md-4 mb-4">
                <div class="product-card">
                    <div class="product-image">
                        <img src="images/puma_shoes/puma4.jpg" class="img-fluid h-100 w-100" alt="">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Brand : puma</h5>
                        <h5 class="product-name">Puma Boy's Shoes</h5>
                        <p class="price"> Rs. 3400 </p>
                        <button class="btn btn-dark w-100">ADD TO CART</button>
                    </div>
                </div>
            </div>

            <!--product5-->
            <div class="col-md-4 mb-4">
                <div class="product-card">
                    <div class="product-image">
                        <img src="images/puma_shoes/puma5.jpg" class="img-fluid h-100 w-100" alt="The Dependables: Black-Blue">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Brand : puma</h5>
                        <h5 class="product-name">Puma Boy's Shoes </h5>
                        <p class="price"> Rs. 1150 </p>
                        <button class="btn btn-dark w-100">ADD TO CART</button>
                    </div>
                </div>
            </div>

            <!--product6-->
            <div class="col-md-4 mb-4">
                <div class="product-card">
                    <div class="product-image">
                        <img src="images/puma_shoes/puma6.jpg" class="img-fluid h-100 w-100" alt="">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Brand : puma</h5>
                        <h5 class="product-name">Puma Girl's Shoes</h5>
                        <p class="price"> Rs. 5540 </p>
                        <button class="btn btn-dark w-100">ADD TO CART</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
