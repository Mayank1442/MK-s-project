<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us </title>
    <!-- Include Bootstrap CSS for basic styling (optional) -->
    <link rel="stylesheet" href="bootstrap.min.css">

    <!-- Include Bootstrap CSS for about page -->
    <link rel="stylesheet" href="about.css">

</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
    <div class="logo">
        <a><img src="images/logo.PNG" width="40" height="40" alt="logo"></a>
    </div>
    <ul class="nav-links">
        <li><a href="home.php">Home</a></li>
        <li class="dropdown">
            <a href="#">Men</a>
            <ul class="dropdown-menu">
                <li><a href="men_sneaker.php">Sneaker</a></li>
                <li><a href="men_walking_shoes.php">Walking Shoes</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">Women</a>
            <ul class="dropdown-menu">
                <li><a href="women_sneaker.php">Sneakers</a></li>
                <li><a href="women_sandal.php">Sandals</a></li>    
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">Children</a>
            <ul class="dropdown-menu">
                <li><a href="children_clog.php">Clogs</a></li>
                <li><a href="children_walking_shoes.php">Walking Shoes</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">Sport</a>
            <ul class="dropdown-menu">
                <li><a href="cricket_shoes.php">Cricket Shoes</a></li>
                <li><a href="football_shoes.php">FootBall Shoes</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">School</a>
            <ul class="dropdown-menu">
                <li><a href="Boy_school_shoes.php">Boys School Shoes</a></li>
                <li><a href="Girl_school_shoes.php">Girls School Shoes</a></li>
            </ul>
        </li>

        <li><a href="contact_us.php">Contact</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="cart.php"><img src="images/cart.png"alt="" width="30px" height="30px"></a></li>
        <li><a href="sign_in.php"><img src="images/adminprofile.png"alt="" width="30px" height="30px"></a></li>
     
    </ul>
</nav>

    <!-- About Us Section -->
    <section class="about-us">
        <h1>About Us</h1>
        <div class="card-container">
            <!-- Mission Card -->
            <div class="card">
                <img src="images\target.png" alt="Mission" class="card-img">
                <h2>Our Mission</h2>
                <p>At ChangeStyle Footwear, our mission is to offer high-quality, stylish, and comfortable footwear for everyone. We believe in combining fashion and function to make every step you take enjoyable and confident.</p>
            </div>
            <!-- Values Card -->
            <div class="card">
                <img src="images\value.png" alt="Mission" class="card-img">
                <h2>Our Values</h2>
                <p>We are committed to sustainability, quality, and customer satisfaction. Our shoes are crafted with care, ensuring both style and durability. We aim to reduce our environmental footprint by using eco-friendly materials and practices.Our webside Provide cash-on delievery facility.
                </p>
            </div>
            <!-- Team Card -->
            <div class="card">
                <img src="images\team.png" alt="Mission" class="card-img">
                <h2>Meet the Team</h2>
                <p>We are a group of shoe multiple shoes companies , our Comany management deparment and Works which is work in our company for the best footwear. Our team works hard to bring you the latest trends and the highest level of service.</p>
            </div>
        </div>
    </section>


    <!-- Footer -->
 
</body>
<footer>
<p>&copy; 2025 Change-Styke. All rights reserved.</p>
<p>Contact: changestyle1@example.com</p>
    </footer>
</html>
