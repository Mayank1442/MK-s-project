<?php
// Start the session
session_start();

// Include your database connection file
include('shoes_admin/includes/dbconnection.php');

// Check if the form has been submitted
if (isset($_POST['submit'])) {
    // Retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to get the user data based on the entered username
    $query = mysqli_query($con, "SELECT * FROM register WHERE username='$username'");
    $result = mysqli_fetch_array($query);

    // Check if the user exists and if the password matches
    if ($result && password_verify($password, $result['password'])) {
        // Set session variables
        $_SESSION['username'] = $username;
        $_SESSION['user_id'] = $result['id'];

        // Redirect to home.php
        echo "<script>window.location.href='home.php';</script>";
    } else {
        // Show an error message if the login fails
        echo "<script>alert('Invalid username or password. Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <link rel="stylesheet" href="css/sign_in.css">
</head>
<body>
    <div class="container">
        <div class="avatar">
            <img src="images\sign-in.png" alt="Avatar">
        </div>
        <br>
        <center>
            <h2>Sign In</h2>
        </center>
        <form action="" method="post">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" placeholder="Enter your username" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter your password" required>

            <button type="submit" name="submit">Login</button>
            <p>Don't have an account? <a href="register.php">Register here</a></p>
        </form>
    </div>
</body>
</html>
