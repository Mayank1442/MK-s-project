<?php 
session_start();
include('shoes_admin/includes/dbconnection.php');

// Function to add product to cart
if (isset($_GET['add_to_cart'])) {
    $product_id = $_GET['add_to_cart'];
    $quantity = 1;

    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];

        if (array_key_exists($product_id, $cart)) {
            $cart[$product_id]['quantity'] += 1;
        } else {
            $query = mysqli_query($con, "SELECT * FROM product WHERE pid = '$product_id'");
            $product = mysqli_fetch_assoc($query);

            $cart[$product_id] = [
                'name' => $product['pname'],
                'price' => $product['cost'],
                'image' => $product['pimage'],
                'quantity' => $quantity
            ];
        }
    } else {
        $cart = [];
        $query = mysqli_query($con, "SELECT * FROM product WHERE pid = '$product_id'");
        $product = mysqli_fetch_assoc($query);

        $cart[$product_id] = [
            'name' => $product['pname'],
            'price' => $product['cost'],
            'image' => $product['pimage'],
            'quantity' => $quantity
        ];
    }

    $_SESSION['cart'] = $cart;
    header('location: cart.php');
}

// Function to remove product from cart
if (isset($_GET['remove'])) {
    $product_id = $_GET['remove'];
    unset($_SESSION['cart'][$product_id]);
    header('location: cart.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css\cart.css" rel="stylesheet">
</head>
<body>
<nav class="navbar">
        <div class="logo">
            <a href="home.php"><img src="images/logo.PNG" width="40" height="40" alt="logo"></a>
        </div>
        <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
            <li class="dropdown">
                <a href="#">Men</a>
                <ul class="dropdown-menu">
                    <li><a href="men_sneaker.php">Sneaker</a></li>
                    <li><a href="men_walking_shoes.php">Walking Shoes</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">Women</a>
                <ul class="dropdown-menu">
                    <li><a href="women_sneaker.php">Sneakers</a></li>
                    <li><a href="women_sandal.php">Sandals</a></li>    
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">Children</a>
                <ul class="dropdown-menu">
                    <li><a href="children_clog.php">Clogs</a></li>
                    <li><a href="children_walking_shoes.php">Walking Shoes</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">Sport</a>
                <ul class="dropdown-menu">
                    <li><a href="cricket_shoes.php">Cricket Shoes</a></li>
                    <li><a href="football_shoes.php">Football Shoes</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">School</a>
                <ul class="dropdown-menu">
                    <li><a href="Boy_school_shoes.php">Boys School Shoes</a></li>
                    <li><a href="Girl_school_shoes.php">Girls School Shoes</a></li>
                </ul>
            </li>
            <li><a href="contact_us.php">Contact</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="cart.php"><img src="images/cart.png"alt="" width="30px" height="30px"></a></li>
            <li><a href="sign_in.php"><img src="images/adminprofile.png" alt="" width="30px" height="30px"></a></li>
        </ul>
    </nav>
    <div class="container">
        <center>
        <h2 class="mb-4 text-center">Shopping Cart</h2></center>
        <?php if (!empty($_SESSION['cart'])): ?>
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Brand Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $total = 0;
                     foreach ($_SESSION['cart'] as $id => $product): 
                        $subtotal = $product['price'] * $product['quantity'];
                        $total += $subtotal;
                    ?>
                    <tr>
                        <td><img src="images/<?php echo $product['image']; ?>" class="product-image" width="100" height="100" alt="<?php echo $product['name']; ?>"></td>
                        <td><?php echo $product['name']; ?></td>
                        <td>Rs. <?php echo $product['price']; ?></td>
                        <td><?php echo $product['quantity']; ?></td>
                        <td>Rs. <?php echo $subtotal; ?></td>
                        <td><a href="cart.php?remove=<?php echo $id; ?>" class="btn-remove">Remove</a></td>
                    </tr>
                    <?php endforeach; ?>
                    <tr>
                        <td colspan="4" align="right"><strong>Total:</strong></td>
                        <td>Rs. <?php echo $total; ?></td>
                        <td><a href="place_order.php?place_order=<?php echo $id; ?>" class="btn-add">Buy</a></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
              <?php else: ?>
            <p class="text-center">Your cart is empty.</p>
        <?php endif; ?>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
<footer>
<p>&copy; 2025 Change-Style. All rights reserved.</p>
<p>Contact: changestyle1@example.com</p>
    </footer>
</html>
