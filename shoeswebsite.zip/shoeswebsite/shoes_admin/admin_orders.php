<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - All Orders</title>
    <!-- Tailwind CSS for modern styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* A little custom CSS to complement Tailwind */
        body {
            background-color: #f8fafc; /* A lighter gray */
        }
    </style>
</head>
<body class="font-sans">

    <?php
    // --- Database Connection ---
    $servername = "localhost";
    $username = "root";  
    $password = "";      
    $dbname = "webshoes"; 

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("<p class='text-center text-red-500 mt-10'>Connection failed: " . $conn->connect_error . "</p>");
    }
    
    // --- Dashboard Metrics ---
    $total_orders = $conn->query("SELECT COUNT(id) as count FROM orders")->fetch_assoc()['count'];
    $total_customers = $conn->query("SELECT COUNT(DISTINCT customer_email) as count FROM orders")->fetch_assoc()['count'];
    $total_revenue_result = $conn->query("SELECT SUM(total_amount) as total FROM orders")->fetch_assoc()['total'];
    $total_revenue = $total_revenue_result ?? 0;

    // --- Search Logic ---
    $search_query = "";
    $sql_orders = "SELECT id, customer_name, customer_email, customer_address, total_amount, order_date FROM orders";
    if (!empty($_GET['search'])) {
        $search_query = $conn->real_escape_string($_GET['search']);
        $sql_orders .= " WHERE customer_name LIKE '%$search_query%' OR customer_email LIKE '%$search_query%' OR id LIKE '%$search_query%'";
    }
    $sql_orders .= " ORDER BY order_date DESC";
    $result_orders = $conn->query($sql_orders);

    ?>

    <div class="container mx-auto p-4 md:p-8">
        
        <!-- Header -->
        <header class="mb-8 flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-bold text-gray-800">📦 Orders Dashboard</h1>
                <p class="text-gray-500">Manage and track all customer orders.</p>
            </div>
            <div class="text-right">
                <p class="text-gray-500 text-sm"><?php echo date("l, F j, Y"); ?></p>
            </div>
        </header>

        <!-- Dashboard Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white p-6 rounded-lg shadow-sm flex items-center">
                <div class="bg-blue-100 text-blue-500 rounded-full p-3 mr-4"><i class="fas fa-box-open fa-lg"></i></div>
                <div>
                    <p class="text-gray-500 text-sm">Total Orders</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $total_orders; ?></p>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-sm flex items-center">
                <div class="bg-yellow-100 text-yellow-500 rounded-full p-3 mr-4"><i class="fas fa-users fa-lg"></i></div>
                <div>
                    <p class="text-gray-500 text-sm">Total Customers</p>
                    <p class="text-2xl font-bold text-gray-800"><?php echo $total_customers; ?></p>
                </div>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-sm flex items-center">
                <div class="bg-green-100 text-green-500 rounded-full p-3 mr-4"><i class="fas fa-dollar-sign fa-lg"></i></div>
                <div>
                    <p class="text-gray-500 text-sm">Total Revenue</p>
                    <p class="text-2xl font-bold text-gray-800">Rs. <?php echo number_format($total_revenue, 2); ?></p>
                </div>
            </div>
        </div>

        <!-- Search and Filter Bar -->
        <div class="bg-white p-4 rounded-lg shadow-sm mb-8">
            <form action="" method="GET" class="flex items-center">
                <input type="text" name="search" placeholder="Search by Order ID, Name, or Email..." value="<?php echo htmlspecialchars($_GET['search'] ?? '', ENT_QUOTES); ?>" class="w-full px-4 py-2 border rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-r-md hover:bg-blue-600"><i class="fas fa-search"></i></button>
            </form>
        </div>

        <!-- Orders Table -->
        <div class="bg-white rounded-lg shadow-sm overflow-hidden">
            <table class="w-full text-sm text-left text-gray-500">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                    <tr>
                        <th scope="col" class="px-6 py-3">Order ID</th>
                        <th scope="col" class="px-6 py-3">Customer</th>
                        <th scope="col" class="px-6 py-3">Date</th>
                        <th scope="col" class="px-6 py-3">Total</th>
                        <th scope="col" class="px-6 py-3"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_orders->num_rows > 0): ?>
                        <?php while($order = $result_orders->fetch_assoc()): ?>
                            <tr class="bg-white border-b">
                                <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">#<?php echo htmlspecialchars($order['id']); ?></th>
                                <td class="px-6 py-4"><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                <td class="px-6 py-4"><?php echo date("M j, Y", strtotime($order['order_date'])); ?></td>
                                <td class="px-6 py-4">Rs. <?php echo number_format($order['total_amount'], 2); ?></td>
                                <td class="px-6 py-4 text-right">
                                    <button onclick="openModal('order-modal-<?php echo $order['id']; ?>')" class="font-medium text-blue-600 hover:underline">View Details</button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center py-12 text-gray-500">No orders found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modals for Order Details -->
    <?php
    if ($result_orders->num_rows > 0) {
        mysqli_data_seek($result_orders, 0); // Reset pointer
        while($order = $result_orders->fetch_assoc()) {
    ?>
    <div id="order-modal-<?php echo $order['id']; ?>" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden">
        <div class="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div class="mt-3 text-center">
                <div class="flex justify-between items-center pb-3">
                    <h3 class="text-lg leading-6 font-medium text-gray-900">Order Details for #<?php echo htmlspecialchars($order['id']); ?></h3>
                    <button onclick="closeModal('order-modal-<?php echo $order['id']; ?>')" class="text-gray-400 hover:text-gray-600">
                        <span class="text-2xl">&times;</span>
                    </button>
                </div>
                <div class="mt-2 text-left">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div>
                            <h4 class="font-bold text-gray-700 mb-2">Customer Details</h4>
                            <p><strong>Name:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($order['customer_email']); ?></p>
                        </div>
                        <div>
                            <h4 class="font-bold text-gray-700 mb-2">Shipping Address</h4>
                            <p><?php echo nl2br(htmlspecialchars($order['customer_address'])); ?></p>
                        </div>
                    </div>
                    
                    <h4 class="font-bold text-gray-700 mb-2">Order Items</h4>
                    <table class="w-full text-sm">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="p-3 font-semibold text-left">Product</th>
                                <th class="p-3 font-semibold text-center">Quantity</th>
                                <th class="p-3 font-semibold text-right">Price</th>
                                <th class="p-3 font-semibold text-right">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $order_id = $order['id'];
                            $stmt_items = $conn->prepare("SELECT product_name, quantity, price FROM order_items WHERE order_id = ?");
                            $stmt_items->bind_param("i", $order_id);
                            $stmt_items->execute();
                            $result_items = $stmt_items->get_result();
                            while($item = $result_items->fetch_assoc()):
                            ?>
                            <tr class="border-t">
                                <td class="p-3"><?php echo htmlspecialchars($item['product_name']); ?></td>
                                <td class="p-3 text-center"><?php echo htmlspecialchars($item['quantity']); ?></td>
                                <td class="p-3 text-right">Rs. <?php echo number_format($item['price'], 2); ?></td>
                                <td class="p-3 text-right">Rs. <?php echo number_format($item['quantity'] * $item['price'], 2); ?></td>
                            </tr>
                            <?php endwhile; $stmt_items->close(); ?>
                        </tbody>
                        <tfoot class="font-bold">
                            <tr class="border-t">
                                <td colspan="3" class="p-3 text-right">Total Amount:</td>
                                <td class="p-3 text-right">Rs. <?php echo number_format($order['total_amount'], 2); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php
        }
    }
    ?>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
    </script>

    <?php $conn->close(); ?>
</body>
</html>
