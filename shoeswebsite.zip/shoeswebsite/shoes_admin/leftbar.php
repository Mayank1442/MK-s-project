<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>

        <a class="navbar-brand" href="index.html" style="display: flex; align-items: center;"> <img
                src="../images/logo.png" alt="Logo"
                style="height: 40px; width: auto; display: inline-block; margin-right: 10px;">Change-Style Footwear</a>
    </div>
    <div class="navbar-default sidebar" role="navigation">
        <div class="sidebar-nav navbar-collapse">
            <ul class="nav" id="side-menu">

                <li>
                    <a href="dashboard.php" style="display: flex; align-items: center;"><svg
                            xmlns="http://www.w3.org/2000/svg" width="23" height="23" fill="black"
                            class="bi bi-house-heart-fill" viewBox="0 0 16 16">
                            <path
                                d="M7.293 1.5a1 1 0 0 1 1.414 0L11 3.793V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5v3.293l2.354 2.353a.5.5 0 0 1-.708.707L8 2.207 1.354 8.853a.5.5 0 1 1-.708-.707z" />
                            <path
                                d="m14 9.293-6-6-6 6V13.5A1.5 1.5 0 0 0 3.5 15h9a1.5 1.5 0 0 0 1.5-1.5zm-6-.811c1.664-1.673 5.825 1.254 0 5.018-5.825-3.764-1.664-6.691 0-5.018" />
                        </svg> Dashboard</a>
                </li>
                <li>
                    <a href="#"><img src="..\images\group.png" width="30" height="30"> Product Group<span
                            class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="add-group.php">Add Group</a>
                        </li>
                        <li>
                            <a href="manage-groups.php">View</a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="#"><img src="..\images\product.png" width="30" height="30">Product<span
                            class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="add-product.php">Add Product</a>
                        </li>
                        <li>
                            <a href="manage-products.php">View</a>
                        </li>
                    </ul>

                </li>
                <li>
                    <a href="admin_orders.php"><img src="https://cdn.iconscout.com/icon/premium/png-256-thumb/complete-order-2914848-2412925.png" width="30" height="30">Orders</a>
                </li>

                <li>
                    <a href="user-account.php"><img src="..\images\registration.png" width="30" height="30">Users List</a>
                </li>

                
                <li>
                    <a href="change-password.php"> <img src="..\images\change password.png" width="40" height="30">Change
                        Password</a>
                </li>
                <li>
                    <a href="admin-profile.php"><img src="..\images\adminprofile.png" width="30" height="30">Admin
                        Profile</a>
                </li>


                <li>
                    <a href="logout.php"><img src="..\images\logout.png" width="30" height="30">Logout</a>
                </li>
            </ul>
        </div>

    </div>

</nav>