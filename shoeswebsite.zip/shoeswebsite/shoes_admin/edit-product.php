<?php
session_start();
include('..\shoes_admin\includes\dbconnection.php');

// Check if the user is logged in
if (strlen($_SESSION['aid']) == 0) {
    header('location:logout.php');
    exit;
} else {
    // Handle form submission
    if (isset($_POST['submit'])) {
        // Retrieve the product ID from the URL (or fallback to 0)
        $pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;

        // Check if the form fields are set and not empty
        if (!empty($pid) && !empty($_POST['pname']) && !empty($_POST['pimage']) && !empty($_POST['cost'])) {
            $pname = $_POST['pname'];
            $pimage = $_POST['pimage'];
            $cost = $_POST['cost'];

            // Run the query and check for errors
            $query = mysqli_query($con, "UPDATE product SET pname='$pname', pimage='$pimage', cost='$cost' WHERE pid='$pid'");

            if ($query) {
                echo '<script>alert("Product updated successfully")</script>';
                echo "<script>window.location.href='manage-products.php'</script>";
                exit;
            } else {
                echo '<div class="alert alert-danger">Error updating product: ' . mysqli_error($con) . '</div>';
            }
        } else {
            echo '<div class="alert alert-warning">Please fill in all fields before submitting!</div>';
        }
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Product</title>

    <!-- Bootstrap Core CSS -->
    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- MetisMenu CSS -->
    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div id="wrapper">
        <!-- Navigation -->
        <?php include('leftbar.php'); ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h4 class="page-header">
                        <?php echo strtoupper("welcome " . htmlentities($_SESSION['login'])); ?>
                    </h4>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Edit Product
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-10">
                                    <?php
                                    // Retrieve product details based on the passed pid
                                    $pid = isset($_GET['pid']) ? intval($_GET['pid']) : 0;
                                    if ($pid > 0) {
                                        $query = mysqli_query($con, "SELECT * FROM `product` WHERE pid='$pid'");
                                        if ($res = mysqli_fetch_array($query)) {
                                    ?>
                                            <form method="post">
                                                <div class="form-group">
                                                    <label>Brand Name</label>
                                                    <input class="form-control" name="pname" id="pname" value="<?php echo $res['pname']; ?>" required="required">
                                                </div>

                                                <div class="form-group">
                                                    <label>Product Image</label>
                                                    <input type="file" class="form-control" name="pimage" id="pimage" value="<?php echo $res['pimage']; ?>" required="required">
                                                </div>

                                                <div class="form-group">
                                                    <label>Cost</label>
                                                    <input class="form-control" name="cost" id="cost" value="<?php echo $res['cost']; ?>" required="required">
                                                </div>

                                                <div class="form-group">
                                                    <input type="submit" class="btn btn-primary" name="submit" value="Update Product">
                                                </div>
                                            </form>
                                    <?php
                                        } else {
                                            echo '<div class="alert alert-danger">Invalid product ID or product not found.</div>';
                                        }
                                    } else {
                                        echo '<div class="alert alert-danger">Product ID not provided.</div>';
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Metis Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>
</body>

</html>
<?php } ?>
