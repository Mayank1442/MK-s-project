<?php session_start();
//error_reporting(0);
include('..\shoes_admin\includes\dbconnection.php');
if (strlen($_SESSION['aid'] == 0)) {
	header('location:logout.php');
} else {

	if (isset($_POST['submit'])) {

		$pgname = $_POST['pgname'];
		$status = $_POST['status'];
		$gid = intval($_GET['gid']);
		$query = mysqli_query($con, "update tbl_group set pgname='$pgname',status='$status' where gid='$gid'");
		if ($query) {
			echo '<script>alert("Group updated successfully")</script>';
			echo "<script>window.location.href='manage-groups.php'</script>";
		} else {
			echo '<script>alert("Something went wrong. Please try again")</script>';
			echo '<script>window.location.href=add-group.php</script>';
		}
	}
	?>
	<!DOCTYPE html>
	<html lang="en">

	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title></title>
		<!-- Bootstrap Core CSS -->
		<link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
		<!-- MetisMenuCSS -->
		<link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
		<!-- Custom CSS -->
		<link href="dist/css/sb-admin-2.css" rel="stylesheet">
		<!-- Custom Fonts -->
		<link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

	</head>

	<body>
		<form method="post">
			<div id="wrapper">

				<!-- Navigation -->
				<?php include('leftbar.php') ?>;


				<div id="page-wrapper">
					<div class="row">
						<div class="col-lg-12">
							<h4 class="page-header">
								<?php echo strtoupper("welcome" . " " . htmlentities($_SESSION['login'])); ?>
							</h4>
						</div>
						<!-- /.col-lg-12 -->
					</div>
					<!-- /.row -->
					<div class="row">
						<div class="col-lg-12">
							<div class="panel panel-default">
								<div class="panel-heading">Edit Group</div>
								<div class="panel-body">
									<div class="row">
										<div class="col-lg-10">


											<?php $gid = intval($_GET['gid']);
											$query = mysqli_query($con, "select * from tbl_group where gid='$gid'");
											$sn = 1;
											$count = mysqli_num_rows($query);
											if ($count > 0) {
												while ($res = mysqli_fetch_array($query)) { ?>


													<div class="form-group">
														<div class="col-lg-4">
															<label>Product Group Name<span id=""
																	style="font-size:11px;color:red">*</span> </label>
														</div>
														<div class="col-lg-6">
															<input class="form-control" name="pgname" id="pgname"
																value="<?php echo $res['pgname']; ?>" required="required"
																onblur="groupAvailability()">
															<span id="group-availability-status" style="font-size:12px;"></span>
														</div>
													</div>
													<br><br>

													<div class="form-group">
														<div class="col-lg-4">
															<label>Status<span id=""
																	style="font-size:11px;color:red">*</span></label>
														</div>
														<div class="col-lg-6">
															<input class="form-control" name="status" id="status"
																value="<?php echo $res['status']; ?>" required="required"
																onblur="groupfullAvail()">
															<span id="course-status" style="font-size:12px;"></span>
														</div>
													</div>

													<br><br>


												</div>
												<br><br>
											<?php }
											} else { ?>

											<h5 style="color:red;" align="center">No record found</h5>
										<?php } ?>

										<div class="form-group">
											<div class="col-lg-4">

											</div>
											<div class="col-lg-6"><br><br>
												<input type="submit" class="btn btn-primary" name="submit"
													value="Update group"></button>
											</div>

										</div>

									</div>

								</div>

							</div>

						</div>

					</div>

				</div>

			</div>


			<script src="bower_components/jquery/dist/jquery.min.js" type="text/javascript"></script>


			<script src="bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>

			<!-- Metis Menu Plugin JavaScript -->
			<script src="bower_components/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>

			<!-- Custom Theme JavaScript -->
			<script src="dist/js/sb-admin-2.js" type="text/javascript"></script>

			<script>
				function courseAvailability() {

					jQuery.ajax({
						url: "group_availability.php",
						data: 'pgname=' + $("#pgname").val(),
						type: "POST",
						success: function (data) {
							$("#group-availability-status").html(data);


						},
						error: function () { }
					});
				}

				function groupfullAvail() {

					jQuery.ajax({
						url: "group_availability.php",
						data: 'status=' + $("#status").val(),
						type: "POST",
						success: function (data) {
							$("group-status").html(data);


						},
						error: function () { }
					});
				}



			</script>
		</form>
	</body>

	</html>
<?php } ?>