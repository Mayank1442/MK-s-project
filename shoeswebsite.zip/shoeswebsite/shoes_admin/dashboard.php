<?php session_start();
//error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['aid'] == 0)) {
    header('location:logout.php');
} else {


?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Dashboard</title>
        <!-- Bootstrap Core CSS -->
        <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- MetisMenu CSS -->
        <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="dist/css/sb-admin-2.css" rel="stylesheet">
        <!-- Custom Fonts -->
        <link href="bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    </head>

    <body class="body">
        <form method="post">
            <div id="wrapper">

                <!-- Navigation -->
                <?php include('leftbar.php'); ?>

                <!--nav-->
                <div id="page-wrapper">
                    <div class="row">
                        <div class="col-lg-12">
                            <h4 class="page-header">
                                <?php echo strtoupper("welcome" . " " . htmlentities($_SESSION['login'])); ?>
                            </h4>
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">Dashboard</div>
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-lg-12">


                                            <!---Product Groups ----->
                                            <div class="col-lg-4 col-md-6">
                                                <div class="panel panel-primary">
                                                    <div class="panel-heading">
                                                        <div class="row">
                                                            <div class="col-xs-3">
                                                                <img src="..\images\group.png" height="90px" width="100px">
                                                            </div>

                                                            <?php $query = mysqli_query($con, "SELECT gid FROM tbl_group");
                                                            $listedgroups = mysqli_num_rows($query);

                                                            ?>


                                                            <div class="col-xs-9 text-right">
                                                                <div class="huge">
                                                                    <?php echo htmlentities($listedgroups); ?>
                                                                </div>
                                                                <div>Listed Groups</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <a href="manage-groups.php">
                                                        <div class="panel-footer">
                                                            <span class="pull-left">View Groups</span>
                                                            <span class="pull-right"> </span>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>


                                            <!------------Product------------>

                                            <div class="col-lg-4 col-md-6">
                                                <div class="panel panel-green">
                                                    <div class="panel-heading">
                                                        <div class="row">
                                                            <div class="col-xs-3">
                                                                <img src="..\images\product.png" height="90px" width="100px">
                                                            </div>
                                                            <?php
                                                            $query1 = mysqli_query($con, "SELECT pid FROM product");
                                                            $tsubjects = mysqli_num_rows($query1);
                                                            ?>

                                                            <div class="col-xs-9 text-right">
                                                                <div class="huge"><?php echo htmlentities($tsubjects); ?>
                                                                </div>
                                                                <div>Product</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <a href="manage-products.php">
                                                        <div class="panel-footer">
                                                            <span class="pull-left">View Product</span>
                                                            <span class="pull-right"></span>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                            <!------------Users List------------>

                                            <div class="col-lg-4 col-md-6">
                                                <div class="panel panel-primary">
                                                    <div class="panel-heading">
                                                        <div class="row">
                                                            <div class="col-xs-3">
                                                                <img src="..\images\registration.png" height="90px" width="100px">
                                                            </div>

                                                            <?php $query = mysqli_query($con, "SELECT id FROM register");
                                                            $listedgroups = mysqli_num_rows($query);

                                                            ?>


                                                            <div class="col-xs-9 text-right">
                                                                <div class="huge">
                                                                    <?php echo htmlentities($listedgroups); ?>
                                                                </div>
                                                                <div>Listed Users</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <a href="user-account.php">
                                                        <div class="panel-footer">
                                                            <span class="pull-left">View Users List</span>
                                                            <span class="pull-right"> </span>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>

                                            <!-- ================================== -->
                                            <!-- ========= NEW ORDERS PANEL ========= -->
                                            <!-- ================================== -->
                                            <div class="col-lg-4 col-md-6">
                                                <div class="panel panel-yellow">
                                                    <div class="panel-heading">
                                                        <div class="row">
                                                            <div class="col-xs-3">
                                                                <img src="https://cdn.iconscout.com/icon/premium/png-256-thumb/complete-order-2914848-2412925.png" width="90" height="100">
                                                            </div>
                                                            <?php
                                                            // Make sure you have an 'orders' table or similar
                                                            $query_orders = mysqli_query($con, "SELECT id FROM orders"); 
                                                            $total_orders = mysqli_num_rows($query_orders);
                                                            ?>
                                                            <div class="col-xs-9 text-right">
                                                                <div class="huge"><?php echo htmlentities($total_orders); ?></div>
                                                                <div>Total Orders</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <a href="admin_orders.php">
                                                        <div class="panel-footer">
                                                            <span class="pull-left">View All Orders</span>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </div>
            </div>

            <script src="bower_components/jquery/dist/jquery.min.js" type="text/javascript"></script>


            <script src="bower_components/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>

            <!-- Metis Menu Plugin JavaScript -->
            <script src="bower_components/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>

            <!-- Custom Theme JavaScript -->
            <script src="dist/js/sb-admin-2.js" type="text/javascript"></script>

            <script>
                function courseAvailability() {
                    $("#loaderIcon").show();
                    jQuery.ajax({
                        url: "course_availability.php",
                        data: 'cshort=' + $("#cshort").val(),
                        type: "POST",
                        success: function(data) {
                            $("#course-availability-status").html(data);
                            $("#loaderIcon").hide();
                        },
                        error: function() {}
                    });
                }

                function coursefullAvail() {
                    $("#loaderIcon").show();
                    jQuery.ajax({
                        url: "course_availability.php",
                        data: 'cfull=' + $("#cfull").val(),
                        type: "POST",
                        success: function(data) {
                            $("#course-status").html(data);
                            $("#loaderIcon").hide();
                        },
                        error: function() {}
                    });
                }
            </script>
        </form>
    </body>

    </html>
<?php } ?>
