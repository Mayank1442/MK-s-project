<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Shoe Store</title>
     
    <link rel="stylesheet" href="css\contact.css">

    <!-- Include Bootstrap CSS for basic styling (optional) -->
    <link rel="stylesheet" href="bootstrap.min.css">

</head>
 

<body>
    <!-- Navbar -->
    <nav class="navbar">
    <div class="logo">
        <a><img src="images/logo.PNG" width="40" height="40" alt="logo"></a>
    </div>
    <ul class="nav-links">
        <li><a href="home.php">Home</a></li>
        <li class="dropdown">
            <a href="#">Men</a>
            <ul class="dropdown-menu">
                <li><a href="men_sneaker.php">Sneaker</a></li>
                <li><a href="men_walking_shoes.php">Walking Shoes</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">Women</a>
            <ul class="dropdown-menu">
                <li><a href="women_sneaker.php">Sneakers</a></li>
                <li><a href="women_sandal.php">Sandals</a></li>    
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">Children</a>
            <ul class="dropdown-menu">
                <li><a href="children_clog.php">Clogs</a></li>
                <li><a href="children_walking_shoes.php">Walking Shoes</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">Sport</a>
            <ul class="dropdown-menu">
                <li><a href="cricket_shoes.php">Cricket Shoes</a></li>
                <li><a href="football_shoes.php">FootBall Shoes</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">School</a>
            <ul class="dropdown-menu">
                <li><a href="Boy_school_shoes.php">Boys School Shoes</a></li>
                <li><a href="Girl_school_shoes.php">Girls School Shoes</a></li>
            </ul>
        </li>

        <li><a href="contact_us.php">Contact</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="cart.php"><img src="images/cart.png"alt="" width="30px" height="30px"></a></li>
        <li><a href="sign_in.php"><img src="images/adminprofile.png"alt="" width="30px" height="30px"></a></li>
     
    </ul>
</nav>

    <!-- Contact Us Form -->
    <div class="container col-6 my-5 p-4">
        <div class="contact-header">
            <h1>Contact Us</h1>
            <p>How Can We Help You?</p>
        </div> 
        <div class="contact-form ">
            <form>
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" placeholder="Enter your full name" required>

                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>

                <label for="message">Message</label>
                <textarea id="message" name="message" rows="5" placeholder="Write your message" required></textarea>

                <button type="submit">Submit</button>
            </form>
        </div>
    </div>
</body>
<footer>
<p>&copy; 2025 Change-Style. All rights reserved.</p>
<p>Contact: changestyle1@example.com</p>
    </footer>
</html>
