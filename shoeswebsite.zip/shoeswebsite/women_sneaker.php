<?php
include('shoes_admin/includes/dbconnection.php');

// Fetch products specifically for Men's Sneakers
$query = "SELECT * FROM product WHERE pgname='Women Sneakers'";
$result = mysqli_query($con, $query);

// Check if the query executed successfully
if (!$result) {
    die("Query failed: " . mysqli_error($con));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Men's Sneakers</title>
    <link rel="stylesheet" href="bootstrap.min.css"> <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="css\product.css"> <!-- Include custom CSS for product styling -->
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <a href="home.php"><img src="images/logo.PNG" width="40" height="40" alt="logo"></a>
        </div>
        <ul class="nav-links">
            <li><a href="home.php">Home</a></li>
            <li class="dropdown">
                <a href="#">Men</a>
                <ul class="dropdown-menu">
                    <li><a href="men_sneaker.php">Sneaker</a></li>
                    <li><a href="men_walking_shoes.php">Walking Shoes</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">Women</a>
                <ul class="dropdown-menu">
                    <li><a href="women_sneaker.php">Sneakers</a></li>
                    <li><a href="women_sandal.php">Sandals</a></li>    
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">Children</a>
                <ul class="dropdown-menu">
                    <li><a href="children_clog.php">Clogs</a></li>
                    <li><a href="children_walking_shoes.php">Walking Shoes</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">Sport</a>
                <ul class="dropdown-menu">
                    <li><a href="cricket_shoes.php">Cricket Shoes</a></li>
                    <li><a href="football_shoes.php">Football Shoes</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="#">School</a>
                <ul class="dropdown-menu">
                    <li><a href="Boy_school_shoes.php">Boys School Shoes</a></li>
                    <li><a href="Girl_school_shoes.php">Girls School Shoes</a></li>
                </ul>
            </li>
            <li><a href="contact_us.php">Contact</a></li>
            <li><a href="about.php">About Us</a></li>
            <li><a href="cart.php"><img src="images/cart.png"alt="" width="30px" height="30px"></a></li>
            <li><a href="sign_in.php"><img src="images/adminprofile.png" alt="" width="30px" height="30px"></a></li>
        </ul>
    </nav>
<br>
    <div>
        <center>
            <h3>Women's Sneakers</h3>
        </center>
    </div>
    <div class="container my-5">
        <div class="row">
            <?php 
            // Loop through the products and display each one
            while ($product = mysqli_fetch_array($result)) { ?>
                <div class="col-md-4 mb-3">
                    <div class="product-card">
                        <div class="product-image">
                            <img src="images/<?php echo htmlentities($product['pimage']); ?>" class="img-fluid h-100 w-100" alt="Product Image">
                        </div>
                        <div class="product-info">
                            <h5 class="product-name">Brand: <?php echo htmlentities($product['pname']); ?></h5>
                            <p class="price">Rs. <?php echo htmlentities($product['cost']); ?></p>
                            <div class="d-flex justify-content-between">
                            <a href="cart.php?add_to_cart=<?php echo htmlentities($product['pid']); ?>" class="btn btn-dark w-100 me-2">Add to Cart</a>
                         </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

    <!-- Include jQuery and Bootstrap JS -->
    <script src="jquery.min.js"></script>
    <script src="bootstrap.min.js"></script>
</body>
<footer>
<p>&copy; 2025 Change-Style. All rights reserved.</p>
<p>Contact: changestyle1@example.com</p>
    </footer>
</html>
