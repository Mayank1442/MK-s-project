<?php 
// Start the session
session_start();

// Include your database connection file
include('shoes_admin\includes\dbconnection.php');

// Check if the form has been submitted
if (isset($_POST['submit'])) {
    // Retrieve form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate if passwords match
    if ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match. Please try again.');</script>";
    } else {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert user data into the database
        $query = mysqli_query($con, "INSERT INTO register (username, email, password) VALUES ('$username', '$email', '$hashed_password')");

        if ($query) {
            // Redirect to home.php after successful registration
            echo "<script>alert('Registration successful!');</script>";
            echo "<script>window.location.href='home.php';</script>";
        } else {
            // Show an error message if the query fails
            echo "<script>alert('Something went wrong. Please try again later.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="css/register.css">
</head>
<body>
    <div class="container">
        <img src="images/registration.png" alt="Profile Image" class="profile-img">
        <h2>Registration</h2>
        <form method="POST" action="">
            <input type="text" name="username" id="username" placeholder="username" required>
            <input type="email" name="email" id="email" placeholder="email" required>
            <input type="password" name="password" id="password" placeholder="password" required>
            <input type="password" name="confirm_password" id="confirm_password" placeholder="confirm password" required>
            <button type="submit" name="submit">Register</button>
        </form>
        <p>Already have an account? <a href="sign_in.php">Sign In here</a></p>
    </div>
</body>
</html>
