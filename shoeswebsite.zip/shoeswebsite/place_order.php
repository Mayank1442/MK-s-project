<?php
session_start();

if (!empty($_SESSION['cart'])) {
    echo "";
    foreach ($_SESSION['cart'] as $item)
        $cartItems[] = [
            'name' => $item['name'],
            'price' => $item['price'],
            'quantity' => $item['quantity']
        ];
}

// Calculate total amount
$totalAmount = 0;
foreach ($_SESSION['cart'] as $item) {
    $totalAmount += $item['price'] * $item['quantity'];
}


// --- Check if the form was submitted ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // --- Database Connection ---
    $servername = "Localhost";
    $username = "root"; // Your DB username
    $password = "";     // Your DB password
    $dbname = "webshoes"; // Your DB name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        $message = "<div class='message error'>Connection failed: " . $conn->connect_error . "</div>";
    } else {
        // --- Get Data from Form ---
        // Sanitize input to prevent XSS
        $customerName = htmlspecialchars($_POST['customer_name']);
        $customerEmail = htmlspecialchars($_POST['customer_email']);
        $customerAddress = htmlspecialchars($_POST['customer_address']);

        // --- Insert into Database ---
        $conn->begin_transaction();

        try {
            // 1. Insert into 'orders' table
            $stmt = $conn->prepare("INSERT INTO orders (customer_name, customer_email, customer_address, total_amount) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sssd", $customerName, $customerEmail, $customerAddress, $totalAmount);
            $stmt->execute();

            // 2. Get the ID of the order we just created
            $orderId = $conn->insert_id;

            // 3. Insert each cart item into 'order_items' table
            $stmt_items = $conn->prepare("INSERT INTO order_items (order_id, product_name, quantity, price) VALUES (?, ?, ?, ?)");
            foreach ($cartItems as $item) {
                $stmt_items->bind_param("isid", $orderId, $item['name'], $item['quantity'], $item['price']);
                $stmt_items->execute();
            }

            // If all queries were successful, commit the transaction
            $conn->commit();
            $message = "<div class='message success'>Thank you! Your order (#$orderId) has been placed successfully!</div>";

            // Clear the cart after successful order (for simulation)
            $cartItems = [];
            $totalAmount = 0;

        } catch (mysqli_sql_exception $exception) {
            // If any query fails, roll back the changes
            $conn->rollback();
            $message = "<div class='message error'>Error: Could not place order. Please try again.</div>";
            // For debugging: error_log($exception->getMessage());
        }

        // Close connections
        if (isset($stmt)) $stmt->close();
        if (isset($stmt_items)) $stmt_items->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: #f4f7f6;
            color: #333;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            width: 100%;
            max-width: 800px;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 25px;
        }
        .checkout-form {
            display: flex;
            flex-direction: column;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #555;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1em;
            box-sizing: border-box; /* Important for padding */
        }
        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }
        .order-summary {
            margin-top: 30px;
            border-top: 2px solid #eee;
            padding-top: 20px;
        }
        .order-summary h2 {
            margin-top: 0;
            color: #34495e;
        }
        .cart-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .cart-item:last-child {
            border-bottom: none;
        }
        .total-row {
            display: flex;
            justify-content: space-between;
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 2px solid #333;
        }
        .submit-btn {
            background-color: #27ae60;
            color: white;
            padding: 15px 20px;
            border: none;
            border-radius: 6px;
            font-size: 1.1em;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }
        .submit-btn:hover {
            background-color: #229954;
        }
        .payment-options {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 20px;
        }
        .payment-option {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .payment-option input {
            width: auto;
            margin-right: 10px;
        }
        .payment-option label {
            font-size: 1.1em;
            color: #555;
        }
        /* Responsive styles */
        @media (max-width: 600px) {
            .container {
                padding: 20px;
            }
            .form-group input, .form-group textarea {
                font-size: 0.9em;
            }
            .submit-btn {
                font-size: 1em;
            }
        }   
        /* Order summary styles */
        .order-card {
            background-color: #fff;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            transition: box-shadow 0.3s ease;
        }
        .order-card:hover { 
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
        }
        /* Message styles */
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 6px;
            text-align: center;
            font-size: 1.1em;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>🛒 Checkout</h1>

        <?php if (isset($message)) echo $message; ?>

        <form action="place_order.php" method="post" class="checkout-form">
            <h2>Customer Details</h2>
            <div class="form-group">
                <label for="customer_name">Full Name</label>
                <input type="text" id="customer_name" name="customer_name" required>
            </div>
            <div class="form-group">
                <label for="customer_email">Email Address</label>
                <input type="email" id="customer_email" name="customer_email" required>
            </div>
            <div class="form-group">
                <label for="customer_phone">Phone Number</label>
                <input type="tel" id="customer_phone" name="customer_phone" required>
            </div>
            <div class="form-group">
                <label for="customer_address">Address</label>
                <textarea id="customer_address" name="customer_address" required></textarea>
            </div>
            <h2>Payment Method</h2>
                <div class="form-group">
                    <div class="payment-options">
                        <div class="payment-option">
                            <input type="radio" id="cod" name="payment_mode" value="Cash on Delivery" required checked>
                            <label for="cod">💵 Cash on Delivery</label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="card" name="payment_mode" value="Credit/Debit Card" required>
                            <label for="card">💳 Credit / Debit Card</label>
                        </div>
                        <div class="payment-option">
                            <input type="radio" id="upi" name="payment_mode" value="UPI" required>
                            <label for="upi">📱 UPI</label>
                        </div>
                    </div>
                </div>

            <?php if (!empty($cartItems)): ?>
            <div class="order-summary">
                <h2>Order Summary</h2>
                <?php foreach ($cartItems as $item): ?>
                    <div class="cart-item">
                        <span><?php echo htmlspecialchars($item['name']); ?> (x<?php echo $item['quantity']; ?>)</span>
                        <span>Rs.<?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                    </div>
                <?php endforeach; ?>
                <div class="total-row">
                    <span>Total</span>
                    <span>Rs.<?php echo number_format($totalAmount, 2); ?></span>
                </div>
            </div>

            <button type="submit" class="submit-btn">Place Order</button>
            <?php else: ?>
                <p>Your cart is empty.</p>
            <?php endif; ?>
        </form>
    </div>

</body>
</html>