<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    
    <link rel="stylesheet" href="./css/home.css">

    <!-- Include Bootstrap CSS for basic styling (optional) -->
    <link rel="stylesheet" href="bootstrap.min.css">

    <!-- Include jQuery -->
    <script src="jquery.min.js"></script>

    <!-- Home jQuery File -->
    <script src="jquery/home.js"></script>

    
</head>

<body>
<nav class="navbar">
    <div class="logo">
        <a><img src="images/logo.PNG" width="40" height="40" alt="logo"></a>
    </div>
    <ul class="nav-links">
        <li><a href="home.php">Home</a></li>
        <li class="dropdown">
            <a href="#">Men</a>
            <ul class="dropdown-menu">
                <li><a href="men_sneaker.php">Sneaker</a></li>
                <li><a href="men_walking_shoes.php">Walking Shoes</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">Women</a>
            <ul class="dropdown-menu">
                <li><a href="women_sneaker.php">Sneakers</a></li>
                <li><a href="women_sandal.php">Sandals</a></li>    
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">Children</a>
            <ul class="dropdown-menu">
                <li><a href="children_clog.php">Clogs</a></li>
                <li><a href="children_walking_shoes.php">Walking Shoes</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">Sport</a>
            <ul class="dropdown-menu">
                <li><a href="cricket_shoes.php">Cricket Shoes</a></li>
                <li><a href="football_shoes.php">FootBall Shoes</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <a href="#">School</a>
            <ul class="dropdown-menu">
                <li><a href="Boy_school_shoes.php">Boys School Shoes</a></li>
                <li><a href="Girl_school_shoes.php">Girls School Shoes</a></li>
            </ul>
        </li>

        <li><a href="contact_us.php">Contact</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="cart.php"><img src="images/cart.png"alt="" width="30px" height="30px"></a></li>
        <li><a href="sign_in.php"><img src="images/adminprofile.png"alt="" width="30px" height="30px"></a></li>
        <li><a href="shoes_admin\login.php"><img src="https://cdn-icons-png.flaticon.com/512/3781/3781986.png" alt="admin" width="30" height="30"></a></li>
    </ul>
</nav>
        <br>
    <center>
        <h1>Welcome To Change Style</h1>
    </center>
    <br>   <div class="slider-container">
        <div class="slider">
            <!-- Slide 1 (2 images) -->
            <div class="slide">
                <img src="images/slider1.jpg" alt="Slide 1 Image 1">
                <img src="images/slider2.jpg" alt="Slide 2 Image 2">
            </div>

            <!-- Slide 2 (2 images) -->
            <div class="slide">
                <img src="images/slider3.jpg" alt="Slide 2 Image 1">
                <img src="images/slide4 (2).jpg" alt="Slide 2 Image 2">
            </div>

            <div class="slide">
                <img src="images/slide5.jpg" alt="Slide 3 Image 1">
                <img src="images/slide6.jpg" alt="Slide 3 Image 2">
            </div>

        </div>

        <!-- Navigation buttons -->
        <button class="arrow prev">Prev</button>
        <button class="arrow next">Next</button>
    </div>
    
 
    <div>
        <center>
            <h3>Product</h3>
        </center>
 <!-- Products -->
        <div class="container my-5">
            <div class="row">
                <!-- Product 1 -->
                <div class="col-md-4 mb-2">
                    <div class="product-home">
                        <img src="images/men's-slider.jpg" class="img-fluid h-100 w-100" alt="The Dependables: Black-Blue" id="img2">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Men's Slipper</h5>
                        <p >Company name: puma</p>
                        <p class="product-price">Rs. 300</p>
                        <button class="btn btn-dark w-100" onclick="location.href='cart.php'">ADD TO CART</button>
                    </div>
                </div>
        
                 <!-- Product 2 -->
                <div class="col-md-4 mb-2">
                    <div class="product-home">
                        <img src="images/women_sliper.jpg" class="img-fluid h-100 w-100" alt="The Dependables: Black-Blue" id="img2">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">women's sliper</h5>
                        <p >Company name: Weiweiwlang</p>
                        <p class="product-price">Rs. 400</p>
                        <button class="btn btn-dark w-100" onclick="location.href='cart.php'">ADD TO CART</button>
                    </div>
                </div>

                 <!-- Product 3 -->
                <div class="col-md-4 mb-2">
                    <div class="product-home">
                        <img src="images/baby_shoes.jpg" class="img-fluid h-100 w-100" alt="The Dependables: Black-Blue" id="img2">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Baby Girl Shoes</h5>
                        <p >Company name: coco</p>
                        <p class="product-price">Rs. 250</p>
                        <button class="btn btn-dark w-100" onclick="location.href='cart.php'">ADD TO CART</button>
                    </div>
                </div>

                 <!-- Product 4 -->
                <div class="col-md-4 mb-2">
                    <div class="product-home">
                        <img src="images/sport's_shoes.jpg" class="img-fluid h-100 w-100" alt="The Dependables: Black-Blue" id="img2">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Sport's Shoes</h5>
                        <p >Company name: Nike</p>
                        <p class="product-price">Rs. 5000</p>
                        <button class="btn btn-dark w-100" onclick="location.href='cart.php'">ADD TO CART</button>
                    </div>
                </div>
        
                 <!-- Product 5 -->
                <div class="col-md-4 mb-2">
                    <div class="product-home">
                        <img src="images/scholl_shoes.jpg" class="img-fluid h-100 w-100" alt="The Dependables: Black-Blue" id="img2">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Boy's School Shoes</h5>
                        <p >Company name: K-D</p>
                        <p class="product-price">Rs. 500</p>
                        <button class="btn btn-dark w-100" onclick="location.href='cart.php'">ADD TO CART</button>
                    </div>
                </div>
 
                  <!-- Product 6 -->
                 <div class="col-md-4 mb-2">
                    <div class="product-home">
                        <img src="images/puma_shoes.jpg" class="img-fluid h-100 w-100" alt="The Dependables: Black-Blue" id="img2">
                    </div>
                    <div class="product-info">
                        <h5 class="product-name">Puma Girl's Shoes</h5>
                        <p >Company name: Puma</p>
                        <p class="product-price">Rs. 500</p>
                        <button class="btn btn-dark w-100" onclick="location.href='cart.php'">ADD TO CART</button>
                    </div>
                </div>
            </div>
        </div>
        
        
</body>
<!-- Footer -->
<footer>
<p>&copy; 2025 Change-Style. All rights reserved.</p>
<p>Contact: changestyle1@example.com</p>
    </footer>
</body>
</html>

</html>